Make sure that ABCRVerX.EXE, OldABC.dll, ABCHelp.EXE and ABCHelp.CFG are in the same directory.
Run ABCRVerX.EXE.  It will create ABC.CFG.
Find the directory(s) containing your *.ABC/*.IDX files.

If the *.ABC/*.IDX files are in the old format it will scan them and create temporary files in
the new format.  By selecting DO NOT REWRITE IN NEW FORMAT, the temporary files will be deleted
after the existing *.ABC/*.IDX files are rewritten without the garbage that has crept into them.
By selecting REWRITE IN NEW FORMAT the files will be rewriten in the new format.  The old format
files will be saved as *.AB1/*.ID1 files so they can be retrieved if there are problems.

If you have problems with ABC Reader Version 20003.04, please post them on the ABC Archives
forum at http://www.allbasiccode.com/cgi-bin/yabb/yabb.cgi

Thank you.

Walt Decker
