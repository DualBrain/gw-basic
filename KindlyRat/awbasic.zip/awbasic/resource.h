//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winmain.rc
//
#define IDM_ABOUT                       100
#define IDD_ABOUTBOX                    100
#define IDM_OPTIONS                     101
#define IDM_RUN                         101
#define IDI_MAZE                        102
#define IDM_NEW                         102
#define IDD_OPTIONS                     103
#define IDM_EXIT                        103
#define IDM_PRINT                       104
#define IDM_OPEN                        104
#define ID_SAVEAS                       105
#define IDM_SAVEAS                      105
#define ID_HELP                         106
#define IDI_ICON4                       106
#define ID_FILE_DEBUGCONSOLE            40001
#define IDM_FILE_DEBUGCONSOLE           40001
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
