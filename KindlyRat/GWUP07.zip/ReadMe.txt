Welcome to GWUP!

GWUP "uncodes" and "protects" GW-BASIC programs that have been encoded with the SAVE "MYPROGRAM",P method, which encodes the program.
To Decode or "uncode" a program you must:

1)  put the program in the same folder as the GWUP exe file
2)  enter the MS-DOS Prompt mode 
3)  find your way back into the file that GWUP is in
4)  enter GWUP U MYPROGRAM.BAS

GWUP will convert the program into the compressed ( default ) mode as MYPROGRAM.GWU and save it in the same file.
To run the decoded program you must change the file name to MYPROGRAM.BAS
It will then run in GW-BASIC and you can save it as SAVE "MYPROGRAM",A to be able to study the program in text form.

To code or "Protect" a program enter GWUP P MYPROGRAM.BAS

Best of Luck!
KindlyRat
25 Feb 2005
