Minimal GWCOM Instructions by KindlyRat.
http://www.geocities.com/KindlyRat
KindlyRat@yahoo.com

You must know some MS-DOS to use the BASCOM compiler. You need not be an expert. GW-BASIC and this compiler operate thru the MS-DOS prompt. I recommend "DOS for Dummies" by Dan Gookin if you must have a book or find a tutorial on line.

1) Find the MS-DOS prompt. From your desktop find the "Start Button" on the lower left corner. Click     Start > Programs > Accessories. The MS-DOS Prompt is in the Accessories Menu. Right Click the MS-DOS Prompt Icon and drag it to your desktop and create a shortcut on your Desktop.

2) Put this COMPILER folder on your desktop too.

3) Put the program that you wish to compile in the COMPILER folder. It must be in ASCII form which means no symbols. If your program is in "Compressed" form, try saving it With the ,A option. If it is in "Protected" form I have a converter on KindlyRat/GWBASIC. In the ASCII form it will appear like a basic program in a training book. It must have a .BAS subscript.

4) Enter the MS-DOS mode by clicking the Icon on your desktop. You must find your way back inside your COMPILER folder. If you have followed directions, CD DESKTOP\COMPILER  entered on the DOS screen should get you there. Enter DIR and you should see your program and the BASCOM and LINK programs.

5) Compile your program. Enter  BASCOM/O without the .bas subscript. The program will load and ask you what Source Filename. Enter your program's name with no ".BAS" Subscript. Hit the Enter key until the COMPILER address comes back. All is well if you had no "Severe Errors".

6) Link your program. Enter LINK. The LINK program will load and it will ask you what Program. Enter your program with no ".BAS"  subscript. Press the Enter key until the COMPILER address comes back.

7) All finished! With no problems, if you enter DIR you will see your program with an ".EXE" subscript. You can enter your program's name on the DOS screen without the ".BAS" and your program will run. You can click it with your mouse and it will run like a real Windows program, except always in a black DOS screen. If you remembered to compile it with the "/O" option, it will be completely independent and you can click and drag it anywhere or e-mail it to the millions of GW-BASIC groupies world-wide!

enjoy!  KindlyRat